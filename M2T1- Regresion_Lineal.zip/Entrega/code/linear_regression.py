import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import utils_model as um
from pyclbr import Class
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics


"""
Linear Regression Model Class"""
class LinearRegressionModel:
    """Initialize and train the Linear Regression model with given data and test size"""
    def __init__(self, X, y , test_size=0.3):
        self.model = None
        self.coefficients = None
        self.intercept = None
        self.predictions = None
        self.scode = self.training_model(X, y, test_size)

    """Train the Linear Regression model and return performance metrics
    input: X (features), y (target), test_size (float)
    output: dict (performance metrics)"""
    def training_model(self, X, y, test_size):
        self.model = LinearRegression()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, shuffle=False, random_state=101)
        self.model.fit(X_train,y_train)
        self.coefficients = self.model.coef_
        self.intercept = self.model.intercept_
        self.predictions = self.model.predict(X_test)
        print("\t predictions: ",self.predictions)
        print("\n=================== Model output results: "+str(test_size)+" ===============")
        print('\t MAE:', metrics.mean_absolute_error(y_test, self.predictions))
        print('\t MSE:', metrics.mean_squared_error(y_test, self.predictions))
        print('\t RMSE:', np.sqrt(metrics.mean_squared_error(y_test, self.predictions)))
        print('\t R^2',self.model.score(X_test, y_test))
        
        results= { "MAE": metrics.mean_absolute_error(y_test, self.predictions),
                "MSE": metrics.mean_squared_error(y_test, self.predictions), 
                "RMSE": np.sqrt(metrics.mean_squared_error(y_test, self.predictions)),
                "R^2": self.model.score(X_test, y_test),
                "intercept": self.model.intercept_,
                "coefficients": self.model.coef_,
                "predictions": self.predictions       
                }
        um.make_graphics(y_test, self.predictions, str(test_size))    
        return um.make_json_serializable(results)

    """Get the performance metrics of the trained model
    output: dict (performance metrics)"""    
    def get_score(self):
        return self.scode



"""Get model performance metrics
input: lm (LinearRegressionModel object)
output: dict (performance metrics)"""
def get_score(lm):
    return um.make_json_serializable(lm.get_score())

"""Get model prediction for given input data
input: lm (LinearRegressionModel object), data (DataFrame)"""
def get_prediction(lm, data):
    prediction = lm.model.predict(data)
    #print("\t Prediction: ",prediction)
    return um.make_json_serializable(prediction)



