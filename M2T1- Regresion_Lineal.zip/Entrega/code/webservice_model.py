import linear_regression as lr
import pandas as pd
import numpy as np 
import utils_model as um  
import test_model as tm  
from flask import Flask, request, jsonify


#Model loading and initialization
app = Flask(__name__)
request_data = pd.read_csv('/home/f0ns1/MASTER_IAS/Modulo2/modelo/kddcup.data_10_percent')
request_data = request_data[request_data["service"] == "http"]
# Modified attack to binary number
request_data['attack_num'] = np.where(request_data['attack_type'].str.strip() == "normal.", 0, 1)
y = request_data['attack_num']
X = request_data[['duration','src_bytes','dst_bytes','land','wrong_fragment','urgent','hot','num_failed_logins','logged_in','num_compromised','root_shell','su_attempted','num_root','num_file_creations','num_shells','num_access_files','num_outbound_cmds','is_host_login','is_guest_login','count','srv_count','serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate','same_srv_rate','diff_srv_rate','srv_diff_host_rate','dst_host_count','dst_host_srv_count','dst_host_same_srv_rate','dst_host_diff_srv_rate','dst_host_same_src_port_rate','dst_host_srv_diff_host_rate','dst_host_serror_rate','dst_host_srv_serror_rate','dst_host_rerror_rate','dst_host_srv_rerror_rate']]
# Create Linear model with test size 30%
lm = lr.LinearRegressionModel(X, y, test_size=0.3)

"""
API endpoint to get model prediction
input: JSON with feature values
output: JSON with prediction result"""
@app.route('/api/score', methods=['POST'])
def model_score():
    data = request.get_json()
    print("DATA input ",data)
    if data != None and um.has_format(data):
        print("Valid format get prediction ")
        inbound = pd.DataFrame([data])
        result = lr.get_prediction(lm, inbound)
        print("Result -->", result)
        attack = "No_attack_detected"
        if result[0] > 0.5:
            attack = "Attack_detected"
        return jsonify({"predction": result, "result": attack})
    else:
        return jsonify({"error": "Invalid input format"}), 400

"""API endpoint to get model information
input: None
output: JSON with model statistics"""
@app.route('/api/model_info', methods=['GET'])
def model_info():
    statics_model = lr.get_score(lm)
    print("Return Data -->", statics_model)
    return statics_model



"""
Init Flask app
Main entry point of webservice
"""
if __name__ == '__main__':
    app.run(debug=True)