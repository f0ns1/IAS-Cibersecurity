import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import linear_resgression as lr 


def draw_line(p1,p2,dash=True):
    plt.plot([p1[0], p2[0]], [p1[1], p2[1]], '--',color='k')

def draw_PCA(X_std,X_pca,W, X, pc1, pc2):
    # Plot the normalized dataset (returned from pca)
    plt.figure()
    plt.scatter(X_std[:, 0], X_std[:, 1], facecolors='none', edgecolors='b')
    plt.xlim(-4, 3)
    plt.ylim(-4, 3)
    plt.gca().set_aspect('equal', adjustable='box')

    print('Projection of the first example: ', W[0, ])
    print('(this value should be about 1.48127391)')

    X_rec = X_pca
    print('Approximation of the first example:', X_rec[0, ])
    print('(this value should be about  -1.04741883 -1.04741883)')

    # Draw lines connecting the projected points to the original points
    plt.scatter(X_rec[:, 0], X_rec[:, 1], facecolors='none', edgecolors='r')
    for i in range(X_std.shape[0]):
        draw_line(X_std[i,:], X_rec[i,:], dash=True)
    axes = plt.gca()
    axes.set_xlim([-4, 3])
    axes.set_ylim([-4, 3])
    axes.set_aspect('equal', adjustable='box')
    plt.savefig("projection_PCA.png")

    # Figura 1: Datos originales
    plt.figure(figsize=(6, 5))
    plt.scatter(X[:, 0], X[:, 1], color='blue')
    plt.title("1. Datos originales (altura vs peso)")
    plt.xlabel("Altura")
    plt.ylabel("Peso")
    plt.grid(True)
    plt.savefig("graficos_originales.png")

    # Figura 2: Datos estandarizados
    plt.figure(figsize=(6, 5))
    plt.scatter(X_std[:, 0], X_std[:, 1], color='green')
    plt.title("2. Datos estandarizados")
    plt.xlabel("Altura (std)")
    plt.ylabel("Peso (std)")
    plt.axhline(0, color='black', linewidth=0.5)
    plt.axvline(0, color='black', linewidth=0.5)
    plt.grid(True)
    plt.savefig("graficos_normalizados.png")


    # Figura 3: Componentes principales sobre los datos
    plt.figure(figsize=(7, 6))
    plt.scatter(X_std[:, 0], X_std[:, 1], color='purple')
    plt.title("3. Componentes principales sobre los datos estandarizados")
    plt.xlabel("Altura (std)")
    plt.ylabel("Peso (std)")
    plt.grid(True)

    # Dibujar los componentes principales
    origin = np.mean(X_std, axis=0)  # centro de los datos

    # Escalado para visualización
    scale = 2

    plt.quiver(origin[0], origin[1], pc1[0], pc1[1],
            angles='xy', scale_units='xy', scale=1,
            color='red', label='PC1')

    plt.quiver(origin[0], origin[1], pc2[0], pc2[1],
            angles='xy', scale_units='xy', scale=1,
            color='orange', label='PC2')

    plt.legend()

    # Figura 4: Proyección en 1D
    plt.figure(figsize=(8, 1.5))
    plt.scatter(X_pca, np.zeros_like(X_pca), color='red')
    plt.title("4. Datos proyectados en el primer componente (1D)")
    plt.yticks([])  # Ocultamos eje Y
    plt.xlabel("PC1")
    plt.grid(True)
    plt.savefig("datos_proyectados.png")






request_data = pd.read_csv('/home/f0ns1/MASTER_IAS/Modulo2/T1M2/modelo/kddcup.data_10_percent')
X = request_data[['duration','src_bytes','dst_bytes','land','wrong_fragment','urgent','hot','num_failed_logins','logged_in','num_compromised','root_shell','su_attempted','num_root','num_file_creations','num_shells','num_access_files','num_outbound_cmds','is_host_login','is_guest_login','count','srv_count','serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate','same_srv_rate','diff_srv_rate','srv_diff_host_rate','dst_host_count','dst_host_srv_count','dst_host_same_srv_rate','dst_host_diff_srv_rate','dst_host_same_src_port_rate','dst_host_srv_diff_host_rate','dst_host_serror_rate','dst_host_srv_serror_rate','dst_host_rerror_rate','dst_host_srv_rerror_rate']]



"""Normalización """
# Media de cada columna
mean = np.mean(X, axis=0)
print("Mean : media de cada columna np.mean(X,axis=0) ", mean)

# Desviación estándar de cada columna
std = np.std(X, axis=0)
print("std : desviación estandar de cada columna np.std(X,axis=0) ",std)

# Datos estandarizados es necesario quitar los NaN
# Asegurar NumPy
X = np.asarray(X, dtype=float)

# Calcular mean y std
mean = X.mean(axis=0)
std = X.std(axis=0)

# Crear máscara: columnas cuya std no es 0
mask = std != 0

X   = X[:, mask]
mean = mean[mask]
std  = std[mask]

# Ahora sí se puede estandarizar
X_std = (X - mean) / std

print("\nDatos estandarizados: (X - mean) / std \n", X_std)

"""
Calculo de covarianzas
"""
cov_matrix = np.cov(X_std.T)   # Transponemos para tener variables en filas

print("\nMatriz de covarianzas: np.cov(X_std.T) \n", cov_matrix)

"""
Calculo de autovalores y autovectores
"""
eig_vals, eig_vecs = np.linalg.eig(cov_matrix)

print("\nAutovalores: np.linalg.eig(cov_matrix) \n", eig_vals)
print("\nAutovectores: np.linalg.eig(cov_matrix) \n", eig_vecs)

"""
Orden de los autovectores de mayor a menor autovalor
"""
# Índices ordenados de mayor a menor autovalor
idx = np.argsort(eig_vals)[::-1]

# Ordenar autovalores y autovectores
eig_vals_sorted = eig_vals[idx]
eig_vecs_sorted = eig_vecs[:, idx]

print("\nAutovalores ordenados:\n", eig_vals_sorted)
print("\nAutovectores ordenados (componentes principales):\n", eig_vecs_sorted)

pc1 = eig_vecs_sorted[:,0]
pc2 = eig_vecs_sorted[:,1]

"""
Proyección matemática para reducción a K componentes
"""
K = 7   # reducir a K
W = eig_vecs_sorted[:, :K]   # matriz de proyección

X_pca = X_std @ W

print(f"\nDatos proyectados en {K} componente(s):\n", X_pca)
request_data['attack_num'] = np.where(request_data['attack_type'].str.strip() == "normal.", 0, 1)
y = request_data['attack_num']
lm = lr.LinearRegressionModel(X_pca, y, test_size=0.3)
draw_PCA(X_std,X_pca,W, X, pc1, pc2)



