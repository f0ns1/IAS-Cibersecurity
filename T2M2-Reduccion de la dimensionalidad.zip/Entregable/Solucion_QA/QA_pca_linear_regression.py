import pandas as pd
import numpy as np 
import scipy.io as sio
import matplotlib.pyplot as plt
import linear_resgression as lr
import json
from sklearn.decomposition import PCA


def min_order(data_list):
    original = data_list.copy()
    best_order = []
    while len(data_list) > 1:
        best = min(data_list)
        index = original.index(best)
        data_list.remove(best)
        best_order.append([index,best])
    return best_order

def max_order(data_list):
    original = data_list.copy()
    best_order = []
    while len(data_list) > 1:
        best = max(data_list)
        index = original.index(best)
        data_list.remove(best)
        best_order.append([index,best])
    return best_order

def QA_MAE(mae_list):
    return min_order(mae_list)

def QA_MSE(mse_list):
    return min_order(mse_list)

def QA_RMSE(rmse_list):
    return min_order(rmse_list)

def QA_R2(r2_list):
    return max_order(r2_list)


def best_index(mae_order, mse_order, rmse_order, r2_order):
    list_order = []
    list_order.append(mae_order[0][0])
    list_order.append(mse_order[0][0])
    list_order.append(rmse_order[0][0])
    list_order.append(r2_order[0][0])
    best_order = list_order.count(r2_order[0][0])
    index = r2_order[0][0]
    if best_order < list_order.count(mae_order[0][0]):
        index = mae_order[0][0]
    if best_order < list_order.count(mse_order[0][0]):
        index = mse_order[0][0]
    if best_order < list_order.count(rmse_order[0][0]):
        index = rmse_order[0][0]
    print("\nBest index:", best_order, " index ", index ,"\n")
    return index 
     
def make_graphic(list_data, name):
    plt.hist(list_data)  
    plt.xlabel('Valores')
    plt.ylabel('Frecuencia')
    plt.title('Histograma de floats')
    plt.savefig(name+'_histograma.png')

    plt.plot(range(len(list_data)), list_data, marker='o')  # 'o' para puntos
    # Límites optimizados para [-1, 1]
    plt.xlim(-0.5, len(list_data)-0.5)  # Margen en X
    plt.ylim(-1.1, 1.1)               # Rango Y ajustado

    # Ticks personalizados para mejor legibilidad
    plt.xticks(range(len(list_data)), [f'{i}' for i in range(len(list_data))], rotation=45)
    plt.yticks(np.arange(-1, 1.1, 0.2))  # Cada 0.2 desde -1 a 1

    plt.xlabel('Índice de la lista')
    plt.ylabel('Valor')
    plt.title('Valores [-1, 1] vs Posición')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(name+'_custom.png')

def QA_process(QA_results, X_r, y):
    print("=================== Model output QA Process: 0.3 ===============")
    num = 1
    MAE_QA = []
    MSE_QA = []
    RMSE_QA = []
    R2_QA = []
    intercept_QA = []
    for resut in QA_results:
        MAE_QA.append(resut['MAE'])
        MSE_QA.append(resut['MSE'])
        RMSE_QA.append(resut['RMSE'])
        R2_QA.append(resut['R^2'])
        intercept_QA.append(resut['intercept'])
        num += 1  
    make_graphic(MAE_QA, "MAE_QA")
    make_graphic(MSE_QA, "MSE_QA")
    make_graphic(RMSE_QA, "RMSE_QA")
    make_graphic(R2_QA, "R2_QA")
    order_mae = QA_MAE(MAE_QA)
    print("\n\t Order MAE : ",order_mae[0][0]," - ", order_mae[0][1])
    order_mse = QA_MSE(MSE_QA)
    print("\n\t Order MSE : ",order_mse[0][0]," - ", order_mse[0][1])
    order_rmse = QA_RMSE(RMSE_QA)
    print("\n\t Order RMSE : ",order_rmse[0][0]," - ", order_rmse[0][1])
    order_r2 = QA_R2(R2_QA)
    print("\n\t Order R2 : ",order_r2[0][0]," - ", order_r2[0][1])
    index = best_index(order_mae, order_mse, order_rmse, order_r2)
   
    print("=================== Model output end QA ===============\n")
    pca = PCA(n_components=index+1)
    X_r = pca.fit_transform(X)
    lm = lr.LinearRegressionModel(X_r, y, test_size=0.3)

"""
Main entry point of webservice
"""
if __name__ == '__main__':
    request_data = pd.read_csv('/home/f0ns1/MASTER_IAS/Modulo2/T1M2/modelo/kddcup.data_10_percent')
    X = request_data[['duration','src_bytes','dst_bytes','land','wrong_fragment','urgent','hot','num_failed_logins','logged_in','num_compromised','root_shell','su_attempted','num_root','num_file_creations','num_shells','num_access_files','num_outbound_cmds','is_host_login','is_guest_login','count','srv_count','serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate','same_srv_rate','diff_srv_rate','srv_diff_host_rate','dst_host_count','dst_host_srv_count','dst_host_same_srv_rate','dst_host_diff_srv_rate','dst_host_same_src_port_rate','dst_host_srv_diff_host_rate','dst_host_serror_rate','dst_host_srv_serror_rate','dst_host_rerror_rate','dst_host_srv_rerror_rate']]
    # Modified attack to binary number
    request_data['attack_num'] = np.where(request_data['attack_type'].str.strip() == "normal.", 0, 1)
    y = request_data['attack_num']
    QA_results = []
    for i in range (len(X.columns)):
        print("PCA num components:", i+1)
        pca = PCA(n_components=i+1)
        X_r = pca.fit_transform(X)
        lm = lr.LinearRegressionModel(X_r, y, test_size=0.3)
        score = lm.get_score()
        QA_results.append(score)
    print("Length of QA_results :", len(QA_results))
    QA_process(QA_results,X_r,y)








#with open('datos_QA.json', 'w') as f:
#    json.dump(QA_results, f, indent=4)

#with open('datos_QA.json', 'r') as f:
#    recover_dict = json.load(f)
#print(recover_dict)

#print("\n\t PCA components ",pca.components_)
#print("\n\t PCA explained variance ",pca.explained_variance_)
#print("\n\t PCA transformed data head ",len(X_r))
#print("PCA 0:5 ", X_r[0:5])

"""
def feature_normalize(X):
    mu = np.mean(X, axis=0)
    sigma = np.std(X, axis=0, ddof=1)
    X_norm = (X - mu) / sigma
    return X_norm, mu, sigma

print("Forma original:", X.shape)
print("NaN por fila:", np.isnan(X).sum(axis=1))
print("Filas con NaN:", np.isnan(X).any(axis=1).sum())
print("% filas eliminables:", np.isnan(X).any(axis=1).sum() / len(X) * 100)
"""

"""
| Aspecto            | func_pca manual            | sklearn.PCA                    |
| ------------------ | ------------------------- | ------------------------------ |
| Centrado           | ❌ No resta la media       | ✅ Centra automáticamente       |
| Escalado           | ❌ No normaliza            | ✅ Opcional (whiten=True)       |
| Salida             | U, S, V(descomposición)   | X_rtransformado directamente   |
| Reducción          | ❌ Manual (X.dot(U[:,:2])) | ✅ Automático conn_components=2 |
| Varianza explicada | ❌ Hay que calcularla      | ✅pca.explained_variance_ratio_ |

def feature_normalize(X):
    mu = np.mean(X, axis=0)
    sigma = np.std(X, axis=0, ddof=1)
    X_norm = (X - mu) / sigma
    return X_norm, mu, sigma


def func_pca(X):
    m, n = X.shape
    sigma = X.T.dot(X) / m
    U, S, V = np.linalg.svd(sigma)
    return U, S, V

#  Before running PCA, it is important to first normalize X
X_norm, mu, sigma = feature_normalize(X)

# Manual completo (equivalente a sklearn)
X_centered = X - np.mean(X, axis=0)  # Centrar
U, S, V = func_pca(X_centered)
X_r_manual = X_centered.dot(U[:, :2])  # Proyectar a 2 componentes [web:42]

""" 



#score = lr.get_score(lm)

#print(score)