import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import json
from sklearn import metrics 
import statsmodels.api as sm

"""
This funcion makes objects json serializable
input: obj (any type)
output: obj (json serializable)
"""
def make_json_serializable(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, (np.int32, np.int64)):
        return int(obj)
    if isinstance(obj, dict):
        return {k: make_json_serializable(v) for k, v in obj.items()}
    return obj

"""
This function makes graphics for model evaluation
input: y_test (array-like), predictions (array-like), header (string)
output: None (saves graphics as PNG file)
"""
def make_graphics(y_test, predictions, header):
    # Calcular métricas
    MAE = metrics.mean_absolute_error(y_test, predictions)
    MSE = metrics.mean_squared_error(y_test, predictions)
    RMSE = np.sqrt(MSE)
    R2 = metrics.r2_score(y_test, predictions)
    residuals = y_test - predictions

    # Metric conjunta 2x2 
    fig, axes = plt.subplots(2, 2, figsize=(14,10))
    fig.suptitle('Evaluación del Modelo de Regresión Lineal', fontsize=18, fontweight='bold')
    sns.scatterplot(x=y_test, y=predictions, ax=axes[0,0], color='teal', s=60, edgecolor='w')
    axes[0,0].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', linewidth=2)
    axes[0,0].set_xlabel('Valores Reales', fontsize=12)
    axes[0,0].set_ylabel('Predicciones', fontsize=12)
    axes[0,0].set_title('Real vs Predicción', fontsize=14, fontweight='bold')
    axes[0,0].text(0.05, 0.95, f'R² = {R2:.3f}', transform=axes[0,0].transAxes,
                fontsize=12, verticalalignment='top', bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.5))

    sns.scatterplot(x=predictions, y=residuals, ax=axes[0,1], color='orange', s=60, edgecolor='w')
    axes[0,1].axhline(0, color='r', linestyle='--', linewidth=2)
    axes[0,1].set_xlabel('Predicciones', fontsize=12)
    axes[0,1].set_ylabel('Residuos', fontsize=12)
    axes[0,1].set_title('Residuos vs Predicciones', fontsize=14, fontweight='bold')
    axes[0,1].text(0.05, 0.95, f'MAE = {MAE:.3f}\nRMSE = {RMSE:.3f}', transform=axes[0,1].transAxes,
                fontsize=12, verticalalignment='top', bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.5))
    sns.histplot(residuals, bins=30, kde=True, ax=axes[1,0], color='skyblue', edgecolor='w')
    axes[1,0].set_xlabel('Residuos', fontsize=12)
    axes[1,0].set_ylabel('Frecuencia', fontsize=12)
    axes[1,0].set_title('Distribución de Residuos', fontsize=14, fontweight='bold')
    sm.qqplot(residuals, line='45', ax=axes[1,1], color='purple')
    axes[1,1].set_title('QQ Plot de Residuos', fontsize=14, fontweight='bold')

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig('complementario_'+header+'.png')

"""This function checks if input data has the required format
input: data (dict)
output: bool (True if format is correct, False otherwise)"""
def has_format(data):
    for keys in json.loads(json.dumps(data)).keys():
        print("hash_formats: ",keys)
    required_fields = ['duration','src_bytes','dst_bytes','land','wrong_fragment','urgent','hot','num_failed_logins','logged_in','num_compromised','root_shell','su_attempted','num_root','num_file_creations','num_shells','num_access_files','num_outbound_cmds','is_host_login','is_guest_login','count','srv_count','serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate','same_srv_rate','diff_srv_rate','srv_diff_host_rate','dst_host_count','dst_host_srv_count','dst_host_same_srv_rate','dst_host_diff_srv_rate','dst_host_same_src_port_rate','dst_host_srv_diff_host_rate','dst_host_serror_rate','dst_host_srv_serror_rate','dst_host_rerror_rate','dst_host_srv_rerror_rate']
    for field in required_fields:
        if field not in data:
            print("Field missing: ",field)
            return False
    print("Hash valid format detected")
    return True